﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;
using V6ThuePostApi;
using V6ThuePostApi.PostObjects;

namespace V6ThuePost
{
    public partial class Form1 : Form
    {
        private string baseUrl = "https://e-invoice.com.vn:8443/InvoiceAPI/";
        private string methodUrl = "/InvoiceAPI/InvoiceWS/createInvoice";
        private string userName = "0100109106-997_5";
        private string password = "111111a@A";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            lblResult.Text = Program.POST(txtUsername.Text, txtPassword.Text, txtMST.Text, richTextBox1.Text);
        }

        

        private void label2_Click(object sender, EventArgs e)
        {

        }

        //private void TestRestSharp()
        //{

        //    var restClient = new RestClient(baseUrl);
        //    //restClient.Authenticator = new HttpBasicAuthenticator(userName, password);

        //    var request = new RestRequest("/InvoiceWS/createInvoice/0100109106-997_5", Method.POST);
        //    request.AddHeader("Authorization", "Basic MDEwMDEwOTEwNi05OTdfNToxMTExMTFhQEE=");
        //    request.AddHeader("Content-Type", "	application/json");
        //    request.AddHeader("Accept", "application/json");
            
        //    request.Parameters.Add(new Parameter
        //    {
        //        Type = ParameterType.RequestBody,
        //        Value = richTextBox1.Text.Trim(),
        //        Name = request.JsonSerializer.ContentType //dòng này là quan trọng nhất vì nó sẽ lấy cái chuỗi "application/json" ở trên biến Request gắn vào tham số <= sáng giờ bị chết ở chỗ này
        //    });
        //    //request.AddJsonBody( richTextBox1.Text);
        //    //request.addbo

        //    ServicePointManager.ServerCertificateValidationCallback +=
        //        (sender, certificate, chain, sslPolicyErrors) => true;
            
        //    IRestResponse response = restClient.Execute(request);
        //    label1.Text = response.Content;
        //    label2.Text = response.ErrorMessage;
        //}

    }
}
