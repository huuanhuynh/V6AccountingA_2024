﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using V6ThuePostApi;

namespace V6ThuePost
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args != null && args.Length > 0)
            {
                string username = args[0];
                string password = args[1];
                string mst = args[2];
                string jsonBody = "";
                string result = POST(username, password, mst, jsonBody);
                //
                return;
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());
            }
        }

        public static string POST(string username, string password, string mst, string jsonBody)
        {
            V6Request.Login(username, password);
            string requestUrl = string.Format("https://e-invoice.com.vn:8443/InvoiceAPI/InvoiceWS/createInvoice/{0}", mst);
            //string jsonBody = richTextBox1.Text;
            string result = V6Request.Request(requestUrl, jsonBody);
            //MessageBox.Show(result);
            return result;
            //lblResult.Text = result;
        }
    }
}
