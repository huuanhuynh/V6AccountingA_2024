﻿namespace V6ThuePostApi.PostObjects
{
    public class BuyerInfo
    {
        public string buyerName = "Lương Thị Huyền";
        public string buyerLegalName = "";
        public string buyerTaxCode = "";
        public string buyerAddressLine = "HN VN";
        public string buyerPhoneNumber = "09880830406";
        public string buyerEmail = "hocpd@viettel.com.vn";
        public string buyerIdNo = "123456789";
        public string buyerIdType = "1";
    }
}
