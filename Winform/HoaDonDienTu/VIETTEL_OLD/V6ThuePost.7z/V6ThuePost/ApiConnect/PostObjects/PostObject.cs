﻿using System.Collections.Generic;

namespace V6ThuePostApi.PostObjects
{
    public class PostObject
    {
        public GeneralInvoiceInfo generalInvoiceInfo = null;
        public BuyerInfo buyerInfo = null;
        public SellerInfo sellerInfo = null;
        public object[] extAttribute = {};

        public Dictionary<string, object> payments = new Dictionary<string, object>()
        {
            {"paymentMethodName", "TM"},
        };

        public object deliveryInfo = null;
        public List<ItemInfo> itemInfo = new List<ItemInfo>();
        public object discountItemInfo = "[]";
        public SummarizeInfo summarizeInfo = null;
        public List<TaxBreakdown> taxBreakdowns = new List<TaxBreakdown>();

    }
}
