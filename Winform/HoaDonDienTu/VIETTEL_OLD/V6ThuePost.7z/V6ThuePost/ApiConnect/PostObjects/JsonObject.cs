﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace V6ThuePostApi.PostObjects
{
    public class JsonObject
    {
        public virtual string ToJson()
        {
            string result = "";
            foreach (PropertyInfo property in GetType().GetProperties())
            {
                if (property.CanRead && property.CanWrite)
                {
                    object value = property.GetValue(this, null);
                    
                    if (value is JsonObject)
                    {
                        result += "," + (JsonObject)value;
                    }
                    else
                    {
                        result += string.Format(",\"{0}\":\"{1}\"", property.Name, value);
                    }
                }
            }

            foreach (FieldInfo field in GetType().GetFields())
            {
                object value = field.GetValue(this);
                if (value is JsonObject)
                {
                    result += "," + (JsonObject)value;
                }
                else
                {
                    result += string.Format(",\"{0}\":\"{1}\"", field.Name, value);
                }
            }

            if (result.Length > 0) result = result.Substring(1);
            return "{" + result + "}";
        }
    }
}
