﻿namespace V6ThuePostApi.PostObjects
{
    public class TaxBreakdown
    {
        public decimal taxPercentage = 10.0m;
        public decimal taxableAmount = 35000000m;
        public decimal taxAmount = 3500000.0m;
    }
}
