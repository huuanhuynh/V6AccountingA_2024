﻿namespace V6ThuePostApi.PostObjects
{
    public class SellerInfo
    {
        public string sellerLegalName = "Supplier perfom test 1";
        public string sellerTaxCode = "0100109106 ";
        public string sellerAddressLine = "test";
        public string sellerPhoneNumber = "0123456789";
        public string sellerEmail = "PerformanceTest1@viettel.com.vn";
        public string sellerBankName = "vtbank";
        public string sellerBankAccount = "23423424";
    }
}
