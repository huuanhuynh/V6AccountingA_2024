﻿using System.Net;

namespace V6ThuePostApi
{
    public static class SendRequest
    {
        #region ==== POST GET ====

        public static string username = "";
        public static string password = "";

        private static readonly RequestManager requestManager = new RequestManager();
        public static string POST(string uri, string request)
        {
            HttpWebResponse respone = requestManager.SendPOSTRequest(uri, request, username, password, true);
            return requestManager.GetResponseContent(respone);
        }
        public static string GET(string uri)
        {
            HttpWebResponse respone = requestManager.SendGETRequest(uri, username, password, true);
            return requestManager.GetResponseContent(respone);
        }
        #endregion post get
    }
}
